#import <Foundation/Foundation.h>

//! Project version number for Experimentation.
FOUNDATION_EXPORT double ExperimentationVersionNumber;

//! Project version string for Experimentation.
FOUNDATION_EXPORT const unsigned char ExperimentationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Experimentation/PublicHeader.h>


