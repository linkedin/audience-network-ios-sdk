#import <Foundation/Foundation.h>

//! Project version number for GroupMatching.
FOUNDATION_EXPORT double GroupMatchingVersionNumber;

//! Project version string for GroupMatching.
FOUNDATION_EXPORT const unsigned char GroupMatchingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GroupMatching/PublicHeader.h>


